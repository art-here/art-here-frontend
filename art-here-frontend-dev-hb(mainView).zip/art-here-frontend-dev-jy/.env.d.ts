interface ImportMeta {
  env: {
    VITE_KAKAO_MAP_KEY: string;
  };
}
