import React, { useEffect, useState } from "react";

export default function useMainViewaction() {

    useEffect(()=>{
        //1. 조건문에 setTimeout||스크롤이벤트 둘 중 하나 주고 조건 참일 때,
        //2. unmount 시켜주기
        return () => {
            //여기에 컴포넌트 사라질 때 동작 로직/style넣기
        }
    },[]);
}