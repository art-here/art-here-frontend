import styled from "styled-components";

import React from "react";
import { useMediaQuery } from "react-responsive";

export default function App(): JSX.Element {
  const isDesktop: boolean = useMediaQuery({
    query: "(min-width:1024px)",
  });
  const isTablet: boolean = useMediaQuery({
    query: "(min-width:768px) and (max-width:1023px)",
  });
  const isMobile: boolean = useMediaQuery({
    query: "(max-width:767px)",
  });

  return (
    <div>
      <h1>반응형 테스트</h1>
      {isDesktop && <p style={{ background: "red" }}>Desktop</p>}
      {isTablet && <p style={{ background: "blue" }}>Tablet</p>}
      {isMobile && <p style={{ background: "green" }}>Mobile</p>}
    </div>
  );
}