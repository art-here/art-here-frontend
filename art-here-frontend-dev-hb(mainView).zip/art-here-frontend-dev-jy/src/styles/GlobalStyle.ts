import { createGlobalStyle } from "styled-components";

export const GlobalStyle = createGlobalStyle`
    html,body{
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        font-family: Cabin, -apple-system, 'Noto Sans KR', sans-serif;
        font-synthesis: none;
        text-rendering: optimizeLegibility;
         -webkit-font-smoothing: antialiased;
         -moz-osx-font-smoothing: grayscale;
        -webkit-text-size-adjust: 100%;
        
        box-sizing: border-box;
    }
    
    body {
        margin: 0;
        display: flex;
        place-items: center;
        min-width: 320px;
        min-height: 100vh;
    }

    a{
        font-weight: 500;
        color: #646cff;
        text-decoration: inherit;
    }

    a:hover {
     color: #535bf2;
    }

    li{
        list-style: none;
    }

    h1 {
    font-size: 3.2em;
    line-height: 1.1;
}

    button {
    border-radius: 8px;
    border: 1px solid transparent;
    padding: 0.6em 1.2em;
    font-size: 1em;
    font-weight: 500;
    font-family: inherit;
    background-color: #1a1a1a;
    cursor: pointer;
    transition: border-color 0.25s;
    }
    button:hover {
    border-color: #646cff;
    }
    button:focus,
    button:focus-visible {
    outline: 4px auto -webkit-focus-ring-color;
    }

    @media (prefers-color-scheme: dark) {
        :root {
            color: #213547;
            background-color: #ffffff;
        }
        a:hover {
            color: #747bff;
        }
        button {
            background-color: #f9f9f9;
        }
    }   
`;
